import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { toast } from 'sonner';
import { AppHeader } from './components/AppHeader';
import { ConfirmDialog } from './components/ConfirmDialog';
import { World } from './components/world/World';
import { useAmbientAudio } from './hooks/useAmbientAudio';
import { usePersistedState } from './hooks/usePersistedState';
import { useSessionLog } from './hooks/useSessionLog';
import { useTimer } from './hooks/useTimer';
import { AppStateContext } from './AppStateContext';
import type { AppActions, AppState, DialogKind } from './AppStateContext';
import { AboutScreen } from './screens/AboutScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { TimerScreen } from './screens/TimerScreen';
import { islandPercent } from './lib/world';
import type { CharacterPose } from './lib/world';
import type { BiomeId } from './lib/biomes';
import { biomeStage, effectiveWeather, isUnlocked, unlockedBiomes } from './lib/biomes';
import { soundscape } from './lib/soundscape';
import { DiscoveryCard } from './components/DiscoveryCard';
import {
  clampDurationMinutes,
  clampProgress,
  clampVolume,
  loadAudio,
  loadAtlas,
  loadBiome,
  loadSessions,
  loadWorld,
  saveAtlas,
  saveAudio,
  saveBiome,
  saveWorld,
} from './lib/storage';
import type { Atlas, AudioSettings, WorldSettings } from './lib/storage';
import type { AuthUser } from './lib/auth';
import { resolveTimeOfDay } from './lib/daycycle';
import type { AmbienceLayer } from './lib/ambience';

const PERSIST_INTERVAL_MS = 5000;
const PERSIST_PROGRESS_STEP = 0.05;
const VOLUME_SAVE_DELAY_MS = 150;
const MIN_SESSION_MS = 1000;

type AppProps = {
  user: AuthUser;
  onLogout: () => void;
};

export default function App({ user, onLogout }: AppProps) {
  const { state, storageUnavailable, update } = usePersistedState();
  const { durationMinutes, muted } = state.settings;
  const totalMs = durationMinutes * 60_000;

  const [progress, setProgress] = useState(state.island.progress);
  const [restored, setRestored] = useState(
    () => state.island.progress > 0 && state.island.progress < 1,
  );

  const [biome, setBiomeState] = useState<BiomeId>(() => loadBiome());
  const [audioPrefs, setAudioPrefs] = useState<AudioSettings>(() => loadAudio());
  const [dialog, setDialog] = useState<DialogKind>(null);
  const [manualAudioOn, setManualAudioOn] = useState(false);
  const [world, setWorld] = useState<WorldSettings>(() => loadWorld());
  const [celebrating, setCelebrating] = useState(false);
  const location = useLocation();

  const lastSaveRef = useRef({ at: 0, progress: state.island.progress });
  const sessionStartedAtRef = useRef<string | null>(null);
  const sessionBiomeRef = useRef<BiomeId>(biome);

  const { items: sessions, stats, record, clear } = useSessionLog();
  const [atlas, setAtlas] = useState<Atlas>(() => loadAtlas(loadSessions(), unlockedBiomes(stats.completed)));
  const [discovery, setDiscovery] = useState<BiomeId | null>(null);
  const completedRef = useRef(stats.completed);
  completedRef.current = stats.completed;
  const unlocked = useMemo(() => unlockedBiomes(stats.completed), [stats.completed]);
  const stage = biomeStage(atlas.byBiome[biome] ?? 0);

  const updateAtlas = useCallback((fn: (prev: Atlas) => Atlas) => {
    setAtlas((prev) => {
      const next = fn(prev);
      saveAtlas(next);
      return next;
    });
  }, []);
  const audio = useAmbientAudio(audioPrefs.volume);
  const { play, stop, setVolume: applyVolume, available: audioAvailable, setAmbience, chime } = audio;

  const percent = islandPercent(progress);

  const setBiome = useCallback((next: BiomeId) => {
    setBiomeState(next);
    saveBiome(next);
  }, []);

  const setVolume = useCallback((value: number) => {
    setAudioPrefs((prev) => ({ ...prev, volume: clampVolume(value) }));
  }, []);

  const setMusicOnStart = useCallback((enabled: boolean) => {
    setAudioPrefs((prev) => ({ ...prev, musicOnStart: enabled }));
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => saveAudio(audioPrefs), VOLUME_SAVE_DELAY_MS);
    return () => window.clearTimeout(timer);
  }, [audioPrefs]);

  useEffect(() => {
    document.documentElement.dataset.biome = biome;
  }, [biome]);

  const updateWorld = useCallback((patch: Partial<WorldSettings>) => {
    setWorld((prev) => {
      const next = { ...prev, ...patch };
      saveWorld(next);
      return next;
    });
  }, []);

  useEffect(() => {
    document.documentElement.dataset.motion = world.motion;
  }, [world.motion]);

  // звук завершения читает актуальные настройки через ref, чтобы не пересоздавать handleComplete
  const chimeRef = useRef({ enabled: world.chime, muted, volume: audioPrefs.volume });
  chimeRef.current = { enabled: world.chime, muted, volume: audioPrefs.volume };
  // на экране таймера завершение видно в панели и над островом — toast нужен только на других страницах
  const pathRef = useRef(location.pathname);
  pathRef.current = location.pathname;

  useEffect(() => {
    applyVolume(audioPrefs.volume);
  }, [applyVolume, audioPrefs.volume]);

  const handleComplete = useCallback(() => {
    const finishedAt = new Date();
    setProgress(1);
    setCelebrating(true);
    if (chimeRef.current.enabled && !chimeRef.current.muted) chime(chimeRef.current.volume);
    if (pathRef.current !== '/') toast.success('Отличная работа!', { description: 'Твой мир стал немного больше.' });
    setDialog((prev) => (prev === 'reset' ? null : prev));
    record({
      startedAt:
        sessionStartedAtRef.current ??
        new Date(finishedAt.getTime() - totalMs).toISOString(),
      endedAt: finishedAt.toISOString(),
      durationMinutes,
      elapsedMs: totalMs,
      biome: sessionBiomeRef.current,
      status: 'completed',
    });
    update((prev) => ({
      ...prev,
      island: { progress: 1, completedAt: finishedAt.toISOString() },
    }));
    // развитие места и открытие новых биомов
    const doneBiome = sessionBiomeRef.current;
    const nowCompleted = completedRef.current + 1;
    updateAtlas((prev) => {
      const fresh = unlockedBiomes(nowCompleted).filter((b) => !prev.seen.includes(b));
      if (fresh.length > 0) window.setTimeout(() => setDiscovery(fresh[0]), 2600);
      return {
        byBiome: { ...prev.byBiome, [doneBiome]: (prev.byBiome[doneBiome] ?? 0) + 1 },
        seen: [...prev.seen, ...fresh],
      };
    });
  }, [chime, durationMinutes, record, totalMs, update, updateAtlas]);

  const timer = useTimer(totalMs, handleComplete);
  const { status, remainingMs } = timer;

  useEffect(() => {
    if (status === 'running' || status === 'paused') {
      setProgress(clampProgress(1 - remainingMs / totalMs));
    }
  }, [status, remainingMs, totalMs]);

  useEffect(() => {
    const shouldPlay =
      status === 'running' && !muted && (audioPrefs.musicOnStart || manualAudioOn);
    if (shouldPlay) play(biome);
    else stop();
  }, [status, muted, biome, audioPrefs.musicOnStart, manualAudioOn, play, stop]);

  const timeOfDay = resolveTimeOfDay(world.timeOfDay, progress, status);
  useEffect(() => {
    document.documentElement.dataset.time = timeOfDay;
  }, [timeOfDay]);

  // Звуковой пейзаж: биом, время суток и погода; играет только во время сессии.
  const weather = effectiveWeather(biome, world.weather);
  const ambienceLayers = useMemo<AmbienceLayer[]>(() => soundscape(biome, timeOfDay, weather), [biome, timeOfDay, weather]);

  const ambienceKey = ambienceLayers.join(',');
  useEffect(() => {
    const active = status === 'running' && !muted && world.ambienceOn;
    setAmbience(active && ambienceKey ? (ambienceKey.split(',') as AmbienceLayer[]) : [], world.ambienceVolume);
  }, [ambienceKey, muted, setAmbience, status, world.ambienceOn, world.ambienceVolume]);

  useEffect(() => {
    if (status !== 'running') return;

    const now = Date.now();
    const last = lastSaveRef.current;
    const farEnoughInTime = now - last.at >= PERSIST_INTERVAL_MS;
    const farEnoughInProgress = Math.abs(progress - last.progress) >= PERSIST_PROGRESS_STEP;
    if (!farEnoughInTime && !farEnoughInProgress) return;

    lastSaveRef.current = { at: now, progress };
    update((prev) => ({ ...prev, island: { progress, completedAt: null } }));
  }, [progress, status, update]);

  const statusRef = useRef(status);
  statusRef.current = status;
  const progressRef = useRef(progress);
  progressRef.current = progress;

  useEffect(() => {
    const flush = () => {
      if (statusRef.current !== 'running' && statusRef.current !== 'paused') return;
      update((prev) => ({
        ...prev,
        island: { progress: progressRef.current, completedAt: null },
      }));
    };

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') flush();
    };

    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('beforeunload', flush);

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('beforeunload', flush);
      flush();
    };
  }, [update]);

  const handleStart = () => {
    setCelebrating(false);
    setProgress(0);
    setRestored(false);
    setManualAudioOn(false);
    lastSaveRef.current = { at: Date.now(), progress: 0 };
    update((prev) => ({ ...prev, island: { progress: 0, completedAt: null } }));
    sessionStartedAtRef.current = new Date().toISOString();
    sessionBiomeRef.current = biome;
    timer.start();
    if (!muted && audioPrefs.musicOnStart) play(biome);
  };

  const handlePause = () => {
    timer.pause();
    update((prev) => ({
      ...prev,
      island: { progress: clampProgress(1 - remainingMs / totalMs), completedAt: null },
    }));
  };

  const applyClearIsland = () => {
    setCelebrating(false);
    setProgress(0);
    setRestored(false);
    setManualAudioOn(false);
    lastSaveRef.current = { at: Date.now(), progress: 0 };
    timer.reset();
    update((prev) => ({ ...prev, island: { progress: 0, completedAt: null } }));
  };

  const applyReset = () => {
    const elapsed = Math.max(0, totalMs - remainingMs);
    if ((status === 'running' || status === 'paused') && elapsed >= MIN_SESSION_MS) {
      record({
        startedAt:
          sessionStartedAtRef.current ??
          new Date(Date.now() - elapsed).toISOString(),
        endedAt: new Date().toISOString(),
        durationMinutes,
        elapsedMs: elapsed,
        biome: sessionBiomeRef.current,
        status: 'aborted',
      });
    }
    applyClearIsland();
  };

  const applyResetProgress = () => {
    applyClearIsland();
    clear();
    updateAtlas(() => ({ byBiome: {}, seen: unlockedBiomes(0) }));
    if (!isUnlocked(biome, 0)) setBiome('meadow');
  };

  const handleChangeDuration = (minutes: number) => {
    const clamped = clampDurationMinutes(minutes);
    update((prev) => ({
      ...prev,
      settings: { ...prev.settings, durationMinutes: clamped },
    }));
    timer.reset(clamped * 60_000);
  };

  const handleToggleMute = () => {
    if (muted) setManualAudioOn(true);
    update((prev) => ({
      ...prev,
      settings: { ...prev.settings, muted: !prev.settings.muted },
    }));
  };

  const confirmDialog = () => {
    const kind = dialog;
    setDialog(null);
    if (kind === 'reset') applyReset();
    else if (kind === 'clearIsland') applyClearIsland();
    else if (kind === 'resetProgress') applyResetProgress();
  };

  const actions: AppActions = {
    start: handleStart,
    pause: handlePause,
    resume: timer.resume,
    requestReset: () => setDialog('reset'),
    requestClearIsland: () => setDialog('clearIsland'),
    requestResetProgress: () => setDialog('resetProgress'),
    changeDuration: handleChangeDuration,
    toggleMute: handleToggleMute,
    setVolume,
    setMusicOnStart,
    setBiome,
    updateWorld,
    dismissDiscovery: () => setDiscovery(null),
    logout: () => {
      stop();
      setAmbience([], 0);
      onLogout();
    },
  };

  const appState: AppState = {
    status,
    remainingMs,
    durationMinutes,
    progress,
    percent,
    restored,
    muted,
    volume: audioPrefs.volume,
    musicOnStart: audioPrefs.musicOnStart,
    audioAvailable,
    storageUnavailable,
    biome,
    sessions,
    stats,
    world,
    timeOfDay,
    ambienceLayers,
    celebrating,
    user,
    atlas,
    unlocked,
    stage,
    weather,
    actions,
  };

  const onTimerScreen = location.pathname === '/';
  const pose: CharacterPose =
    status === 'running' ? 'building' : status === 'completed' || celebrating ? 'cheering' : 'resting';

  return (
    <AppStateContext.Provider value={appState}>
      <div className="relative min-h-dvh" data-motion={world.motion}>
        <div className={onTimerScreen ? 'world-host world-host--stage' : 'world-host world-host--backdrop'}>
          <World
            biome={biome}
            progress={progress}
            time={timeOfDay}
            weather={world.weather}
            stage={stage}
            effects={world.effects}
            motion={world.motion}
            pose={pose}
            celebrating={celebrating}
            layout={onTimerScreen ? 'stage' : 'backdrop'}
          />
        </div>

        <AppHeader />

        <main className="relative z-10">
          <div key={location.pathname} className="page-enter">
          <Routes location={location}>
            <Route path="/" element={<TimerScreen />} />
            <Route path="/settings" element={<SettingsScreen />} />
            <Route path="/progress" element={<ProgressScreen />} />
            <Route path="/about" element={<AboutScreen />} />
            <Route path="/login" element={<Navigate to="/" replace />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          </div>
        </main>
        {discovery && status !== 'running' && (
          <DiscoveryCard
            biome={discovery}
            onGo={() => {
              setBiome(discovery);
              setDiscovery(null);
            }}
            onLater={() => setDiscovery(null)}
          />
        )}
      </div>

      <ConfirmDialog
        open={dialog === 'reset'}
        title="Сбросить сессию?"
        description="Таймер вернётся к началу, а постройки этой сессии исчезнут. Прерванная сессия попадёт в журнал."
        confirmLabel="Сбросить"
        onConfirm={confirmDialog}
        onCancel={() => setDialog(null)}
      />
      <ConfirmDialog
        open={dialog === 'clearIsland'}
        title="Очистить остров?"
        description="Постройки исчезнут, журнал сессий останется. Таймер не запустится."
        confirmLabel="Очистить"
        onConfirm={confirmDialog}
        onCancel={() => setDialog(null)}
      />
      <ConfirmDialog
        open={dialog === 'resetProgress'}
        title="Сбросить весь прогресс?"
        description="Остров и вся история сессий этого аккаунта будут удалены. Действие нельзя отменить."
        confirmLabel="Удалить всё"
        onConfirm={confirmDialog}
        onCancel={() => setDialog(null)}
      />
    </AppStateContext.Provider>
  );
}
