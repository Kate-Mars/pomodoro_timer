import { useCallback, useState } from 'react';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import App from './App';
import { AuthScreen } from './screens/AuthScreen';
import { getCurrentUser, logout } from './lib/auth';
import type { AuthUser } from './lib/auth';
import { setStorageScope } from './lib/storage';
import { TooltipProvider } from './components/ui/tooltip';
import { Toaster } from './components/ui/sonner';

function initialUser(): AuthUser | null {
  const user = getCurrentUser();
  // область хранения задаётся до первого рендера App, чтобы все хуки прочитали данные этого аккаунта
  setStorageScope(user?.id ?? null);
  return user;
}

/** Без входа доступен только экран /login; после входа App монтируется заново для каждого аккаунта. */
export function AuthGate() {
  const [user, setUser] = useState<AuthUser | null>(initialUser);
  const navigate = useNavigate();
  const location = useLocation();

  const handleAuthenticated = useCallback(
    (next: AuthUser) => {
      setStorageScope(next.id);
      setUser(next);
      const from = (location.state as { from?: string } | null)?.from;
      navigate(from && from !== '/login' ? from : '/', { replace: true });
    },
    [location.state, navigate],
  );

  const handleLogout = useCallback(() => {
    logout();
    setStorageScope(null);
    setUser(null);
    navigate('/login', { replace: true });
  }, [navigate]);

  return (
    <TooltipProvider>
      {user ? (
        <App key={user.id} user={user} onLogout={handleLogout} />
      ) : (
        <Routes>
          <Route path="/login" element={<AuthScreen onAuthenticated={handleAuthenticated} />} />
          <Route path="*" element={<Navigate to="/login" replace state={{ from: location.pathname }} />} />
        </Routes>
      )}
      <Toaster position="bottom-right" mobileOffset={{ bottom: 92 }} />
    </TooltipProvider>
  );
}
