import { useCallback, useRef, useState } from 'react';
import { loadState, saveState } from '../lib/storage';
import type { LoadResult, PersistedState } from '../lib/storage';

export type PersistedStore = {
  state: PersistedState;
  storageUnavailable: boolean;
  update: (updater: (prev: PersistedState) => PersistedState) => void;
};

export function usePersistedState(): PersistedStore {
  const initialRef = useRef<LoadResult | null>(null);
  if (initialRef.current === null) {
    initialRef.current = loadState();
  }

  const [state, setState] = useState<PersistedState>(initialRef.current.state);
  const [storageUnavailable, setStorageUnavailable] = useState(initialRef.current.storageUnavailable);
  const stateRef = useRef(state);
  stateRef.current = state;

  const update = useCallback((updater: (prev: PersistedState) => PersistedState) => {
    const next = updater(stateRef.current);
    stateRef.current = next;
    setState(next);
    if (!saveState(next)) {
      setStorageUnavailable(true);
    }
  }, []);

  return { state, storageUnavailable, update };
}
