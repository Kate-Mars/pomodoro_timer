import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff, Loader2, LogIn, ShieldCheck, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { AuthError, login, register } from '@/lib/auth';
import type { AuthUser } from '@/lib/auth';
import { World } from '@/components/world/World';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const emailField = z.string().trim().min(1, 'Введите email').pipe(z.email('Email в формате name@example.com'));

const loginSchema = z.object({
  email: emailField,
  password: z.string().min(1, 'Введите пароль'),
});

const registerSchema = z
  .object({
    name: z.string().trim().min(2, 'Имя — от 2 символов').max(32, 'Имя — до 32 символов'),
    email: emailField,
    password: z
      .string()
      .min(8, 'Пароль — минимум 8 символов')
      .regex(/[A-Za-zА-Яа-яЁё]/, 'Добавьте хотя бы одну букву')
      .regex(/\d/, 'Добавьте хотя бы одну цифру'),
    confirm: z.string().min(1, 'Повторите пароль'),
  })
  .refine((v) => v.password === v.confirm, { path: ['confirm'], message: 'Пароли не совпадают' });

type LoginValues = z.infer<typeof loginSchema>;
type RegisterValues = z.infer<typeof registerSchema>;

function PasswordInput(props: React.ComponentProps<typeof Input>) {
  const [shown, setShown] = useState(false);
  return (
    <div className="relative">
      <Input {...props} type={shown ? 'text' : 'password'} className="pr-11" />
      <Button
        type="button"
        variant="ghost"
        size="icon-sm"
        className="absolute top-1 right-1"
        onClick={() => setShown((s) => !s)}
        aria-label={shown ? 'Скрыть пароль' : 'Показать пароль'}
      >
        {shown ? <EyeOff /> : <Eye />}
      </Button>
    </div>
  );
}

function FormError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {message}
    </p>
  );
}

function LoginForm({ onDone }: { onDone: (u: AuthUser) => void }) {
  const [formError, setFormError] = useState<string | null>(null);
  const form = useForm<LoginValues>({ resolver: zodResolver(loginSchema), defaultValues: { email: '', password: '' }, mode: 'onTouched' });
  const submitting = form.formState.isSubmitting;

  const onSubmit = async (values: LoginValues) => {
    setFormError(null);
    try {
      const user = await login(values);
      toast.success(`С возвращением, ${user.name}!`);
      onDone(user);
    } catch (e) {
      setFormError(e instanceof AuthError ? e.message : 'Что-то пошло не так. Попробуйте ещё раз.');
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} noValidate className="grid gap-4">
        <FormError message={formError} />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" autoComplete="email" placeholder="you@example.com" disabled={submitting} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Пароль</FormLabel>
              <FormControl>
                <PasswordInput autoComplete="current-password" disabled={submitting} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" size="lg" disabled={submitting}>
          {submitting ? <Loader2 className="animate-spin" /> : <LogIn />}
          {submitting ? 'Входим…' : 'Войти'}
        </Button>
      </form>
    </Form>
  );
}

function RegisterForm({ onDone }: { onDone: (u: AuthUser) => void }) {
  const [formError, setFormError] = useState<string | null>(null);
  const form = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: { name: '', email: '', password: '', confirm: '' },
    mode: 'onTouched',
  });
  const submitting = form.formState.isSubmitting;

  const onSubmit = async (values: RegisterValues) => {
    setFormError(null);
    try {
      const user = await register(values);
      toast.success(`Остров для ${user.name} готов к стройке`);
      onDone(user);
    } catch (e) {
      if (e instanceof AuthError && e.field === 'email') form.setError('email', { message: e.message });
      else setFormError(e instanceof AuthError ? e.message : 'Что-то пошло не так. Попробуйте ещё раз.');
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} noValidate className="grid gap-4">
        <FormError message={formError} />
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Имя</FormLabel>
              <FormControl>
                <Input autoComplete="nickname" placeholder="Как подписать твой мир" disabled={submitting} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" autoComplete="email" placeholder="you@example.com" disabled={submitting} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Пароль</FormLabel>
              <FormControl>
                <PasswordInput autoComplete="new-password" disabled={submitting} {...field} />
              </FormControl>
              <FormDescription>Минимум 8 символов, буквы и цифры.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="confirm"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Повтор пароля</FormLabel>
              <FormControl>
                <PasswordInput autoComplete="new-password" disabled={submitting} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" size="lg" disabled={submitting}>
          {submitting ? <Loader2 className="animate-spin" /> : <UserPlus />}
          {submitting ? 'Создаём остров…' : 'Создать аккаунт'}
        </Button>
      </form>
    </Form>
  );
}

export function AuthScreen({ onAuthenticated }: { onAuthenticated: (user: AuthUser) => void }) {
  useEffect(() => {
    document.documentElement.dataset.time = 'sunset';
  }, []);
  return (
    <div className="relative min-h-dvh">
      <div className="world-host">
        <World biome="cherry" progress={0.62} time="sunset" weather="clear" effects motion="full" pose="resting" celebrating={false} layout="stage" />
      </div>
      <div className="relative z-10 flex min-h-dvh flex-col px-3 py-4 sm:px-6 lg:px-8">
        <Logo />
        <div className="flex flex-1 items-end justify-center py-6 lg:items-center lg:justify-start">
          <section className="panel w-full max-w-[420px] rounded-lg p-5 sm:p-6" aria-labelledby="auth-title">
            <h1 id="auth-title" className="text-2xl font-extrabold tracking-tight">
              Твой остров ждёт
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">Работай по Помодоро — и смотри, как растёт твой маленький мир.</p>
            <Tabs defaultValue="login" className="mt-5">
              <TabsList className="w-full">
                <TabsTrigger value="login">Вход</TabsTrigger>
                <TabsTrigger value="register">Регистрация</TabsTrigger>
              </TabsList>
              <TabsContent value="login">
                <LoginForm onDone={onAuthenticated} />
              </TabsContent>
              <TabsContent value="register">
                <RegisterForm onDone={onAuthenticated} />
              </TabsContent>
            </Tabs>
            <p className="mt-5 flex gap-2 text-xs text-muted-foreground">
              <ShieldCheck className="size-4 shrink-0 text-primary" />
              Учебный прототип: аккаунт хранится только в этом браузере, пароль — в виде хеша. На сервер ничего не отправляется.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
