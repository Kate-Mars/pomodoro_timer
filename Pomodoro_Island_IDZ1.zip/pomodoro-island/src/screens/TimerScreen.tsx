import { useAppState } from '@/AppStateContext';
import { TimerPanel } from '@/components/TimerPanel';

export function TimerScreen() {
  const { celebrating, status } = useAppState();
  return (
    <div className="relative flex min-h-[calc(100dvh-64px)] flex-col justify-end px-3 pb-[88px] sm:px-6 md:pb-6 lg:justify-center lg:px-8 lg:pb-8">
      <h1 className="sr-only">Таймер и остров</h1>
      {celebrating && status === 'completed' && (
        <p className="completion-banner pointer-events-none absolute inset-x-0 top-2 z-10 text-center lg:top-6 lg:pl-[clamp(380px,32vw,460px)]">
          <span className="panel inline-block rounded-md px-4 py-2 text-sm font-semibold text-accent">Твой мир стал немного больше</span>
        </p>
      )}
      <div className="w-full max-w-[420px] self-center lg:self-start">
        <TimerPanel />
      </div>
    </div>
  );
}
