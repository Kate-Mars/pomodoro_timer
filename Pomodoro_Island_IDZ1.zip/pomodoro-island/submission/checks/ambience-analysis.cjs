const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  await p.goto('http://127.0.0.1:5173/login');
  await p.waitForTimeout(1200);
  const res = await p.evaluate(async () => {
    const { AmbienceEngine } = await import('/src/lib/ambience.ts');
    const layers = ['rain', 'wind', 'stream', 'birds', 'fire', 'leaves', 'waves', 'night', 'drips'];
    const runs = layers.map((layer) => {
      const ctx = new AudioContext();
      const an = ctx.createAnalyser(); an.fftSize = 4096; an.smoothingTimeConstant = 0;
      const sink = ctx.createGain(); sink.gain.value = 0; an.connect(sink).connect(ctx.destination);
      const eng = new AmbienceEngine(ctx, an);
      eng.setLayers([layer], 0.5);
      return { layer, ctx, an, eng, rms: [], spec: new Float64Array(an.frequencyBinCount) };
    });
    const td = new Float32Array(4096); const fd = new Float32Array(2048);
    for (let t = 0; t < 60; t++) {
      await new Promise((r) => setTimeout(r, 250));
      for (const r of runs) {
        if (t < 12) continue; // после плавного появления
        r.an.getFloatTimeDomainData(td); let e = 0; for (const v of td) e += v * v; r.rms.push(10 * Math.log10(e / td.length + 1e-12));
        r.an.getFloatFrequencyData(fd); for (let k = 0; k < fd.length; k++) r.spec[k] += Math.pow(10, fd[k] / 10);
      }
    }
    return runs.map((r) => {
      const sr = r.ctx.sampleRate; const bin = sr / 4096; const bands = { sub: 0, low: 0, mid: 0, high: 0, air: 0 }; let tot = 0;
      r.spec.forEach((v, k) => { const f = k * bin; tot += v; if (f < 100) bands.sub += v; else if (f < 250) bands.low += v; else if (f < 2000) bands.mid += v; else if (f < 6000) bands.high += v; else bands.air += v; });
      for (const k in bands) bands[k] = +(100 * bands[k] / tot).toFixed(1);
      const sorted = [...r.rms].sort((a, b) => a - b);
      r.eng.dispose(); r.ctx.close();
      return { layer: r.layer, medianDb: +sorted[Math.floor(sorted.length / 2)].toFixed(1), maxDb: +sorted[sorted.length - 1].toFixed(1), bands, state: r.ctx.state };
    });
  });
  for (const r of res) console.log(r.layer.padEnd(7), 'median', r.medianDb, 'max', r.maxDb, JSON.stringify(r.bands));
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
