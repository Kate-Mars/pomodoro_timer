const { chromium } = require('playwright');
const S = process.argv[2];
const log = (...a) => console.log('✓', ...a);
const assert = (c, m) => { if (!c) { console.log('✗ FAIL', m); process.exitCode = 1; } else log(m); };
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1440, height: 1000 } });
  const p = await ctx.newPage();
  const errs = [];
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await p.clock.install();
  const B = 'http://127.0.0.1:5173';
  await p.goto(B + '/');
  await p.waitForURL(B + '/login'); log('гость перенаправлен на /login');
  // register with validation errors
  await p.getByRole('tab', { name: 'Регистрация' }).click();
  await p.getByRole('button', { name: 'Создать аккаунт' }).click();
  await p.clock.runFor(300);
  const errCount = await p.locator('[data-slot="form-message"]').count();
  assert(errCount >= 3, 'пустая форма показывает ошибки валидации (' + errCount + ')');
  await p.getByLabel('Имя').fill('Тест');
  await p.getByLabel('Email').fill('test@example.com');
  await p.getByLabel('Пароль', { exact: true }).fill('island2026');
  await p.getByLabel('Повтор пароля').fill('island2026');
  await p.getByRole('button', { name: 'Создать аккаунт' }).click();
  await p.clock.runFor(3000);
  await p.waitForURL(B + '/'); log('регистрация → таймер');
  const raw = await p.evaluate(() => localStorage.getItem('pomodoro.users.v1'));
  assert(!raw.includes('island2026') && raw.includes('"hash"'), 'пароль не хранится открытым текстом');
  // custom duration 1 min
  const inp = p.getByLabel('Своя длительность в минутах');
  await inp.fill('1'); await inp.press('Enter'); await p.clock.runFor(300);
  assert((await p.locator('.timer-digits').first().innerText()).includes('01:00'), 'своя длительность 1 мин');
  await p.getByRole('button', { name: 'Старт' }).click();
  await p.clock.runFor(10_000);
  assert(await inp.isDisabled(), 'длительность заблокирована во время сессии');
  await p.getByRole('button', { name: 'Пауза' }).click();
  const t1 = await p.locator('.timer-digits').first().innerText();
  await p.clock.runFor(15_000);
  const t2 = await p.locator('.timer-digits').first().innerText();
  assert(t1 === t2, 'пауза удерживает время (' + t1 + ')');
  // navigate during session
  await p.getByRole('link', { name: 'Настройки' }).first().click(); await p.clock.runFor(500);
  await p.getByRole('link', { name: 'Таймер' }).first().click(); await p.clock.runFor(500);
  assert((await p.locator('.timer-digits').first().innerText()) === t1, 'навигация не сбрасывает сессию');
  // reset confirmation cancel
  await p.getByRole('button', { name: 'Сбросить сессию' }).click();
  await p.getByRole('alertdialog').waitFor();
  await p.getByRole('button', { name: 'Отмена' }).click(); await p.clock.runFor(400);
  assert((await p.locator('.timer-digits').first().innerText()) === t1, 'сброс требует подтверждения (отмена сохраняет сессию)');
  await p.getByRole('button', { name: 'Продолжить' }).click();
  await p.clock.runFor(55_000);
  await p.screenshot({ path: S + '/e2e-complete.png' });
  const body = await p.locator('body').innerText();
  assert(body.toLowerCase().includes('отличная работа!'), 'сессия завершена, статус «Отличная работа!»');
  assert(body.includes('Твой мир стал немного больше'), 'сообщение «Твой мир стал немного больше»');
  // discovery of a new biome after the first completed session
  await p.clock.runFor(3200); await p.waitForTimeout(500);
  const disc = await p.getByText('Новое место').isVisible().catch(() => false);
  assert(disc, 'после первой сессии открыто новое место (карточка открытия)');
  await p.screenshot({ path: S + '/e2e-discovery.png' });
  await p.getByRole('button', { name: 'Отправиться' }).click(); await p.clock.runFor(1500); await p.waitForTimeout(300);
  assert(await p.evaluate(() => document.documentElement.dataset.biome) === 'cherry', '«Отправиться» переключает на Сакуровую рощу');
  // reload persistence
  await p.reload(); await p.clock.runFor(1500);
  await p.getByRole('link', { name: 'Прогресс' }).first().waitFor(); await p.clock.runFor(500);
  await p.getByRole('link', { name: 'Прогресс' }).first().click(); await p.clock.runFor(800); await p.waitForURL(B + '/progress'); await p.clock.runFor(1000); await p.waitForTimeout(800);
  const prog = await p.locator('main').innerText();
  assert(/Сессий завершено\s*1/.test(prog), 'журнал/статистика сохранились после перезагрузки');
  await p.screenshot({ path: S + '/e2e-progress.png' });
  // logout & wrong password & login
  await p.getByRole('button', { name: /Аккаунт|Т/ }).last().click().catch(()=>{});
  await p.getByRole('menuitem', { name: 'Выйти' }).click();
  await p.waitForURL(B + '/login'); log('выход → /login');
  await p.getByLabel('Email').fill('test@example.com');
  await p.getByLabel('Пароль', { exact: true }).fill('wrongpass1');
  await p.getByRole('button', { name: 'Войти' }).click(); await p.clock.runFor(3000);
  const okErr = await p.getByText('Неверный email или пароль').waitFor({ timeout: 8000 }).then(() => true, () => false);
  assert(okErr, 'неверный пароль → ошибка');
  // duplicate email
  await p.getByRole('tab', { name: 'Регистрация' }).click();
  await p.getByLabel('Имя').fill('Другой');
  await p.getByLabel('Email').fill('TEST@example.com');
  await p.getByLabel('Пароль', { exact: true }).fill('island2026');
  await p.getByLabel('Повтор пароля').fill('island2026');
  await p.getByRole('button', { name: 'Создать аккаунт' }).click(); await p.clock.runFor(3000);
  assert((await p.locator('body').innerText()).includes('уже есть'), 'повторный email → ошибка');
  await p.getByRole('tab', { name: 'Вход' }).click();
  await p.getByLabel('Email').fill('test@example.com');
  await p.getByLabel('Пароль', { exact: true }).fill('island2026');
  await p.getByRole('button', { name: 'Войти' }).click(); await p.clock.runFor(3000);
  await p.waitForURL(B + '/'); await p.clock.runFor(1000); await p.waitForTimeout(500);
  await p.getByRole('link', { name: 'Прогресс' }).first().click(); await p.clock.runFor(1000); await p.waitForURL(B + '/progress'); await p.waitForTimeout(800);
  assert(/Сессий завершено\s*1/.test(await p.locator('main').innerText()), 'после повторного входа данные на месте');
  // new context = "restart browser"? same storage via storageState
  const state = await ctx.storageState();
  const ctx2 = await b.newContext({ viewport: { width: 1440, height: 1000 }, storageState: state });
  const p2 = await ctx2.newPage(); await p2.goto(B + '/progress'); await p2.waitForTimeout(1500);
  assert(/Сессий завершено\s*1/.test(await p2.locator('main').innerText()), 'новая вкладка/перезапуск: сессия и данные сохранены');
  console.log('errors:', JSON.stringify(errs));
  await b.close();
})().catch(e => { console.error('CRASH', e.message); process.exit(1); });
