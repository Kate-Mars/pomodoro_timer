const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('http://127.0.0.1:5173/login');
  await p.waitForTimeout(1500);
  const res = await p.evaluate(async () => {
    const { MusicEngine } = await import('/src/lib/music.ts');
    const SR = 44100, SECS = 75;
    function fftMag(x) { // radix-2 real FFT magnitude
      const n = x.length; const re = Float64Array.from(x); const im = new Float64Array(n);
      for (let i = 1, j = 0; i < n; i++) { let bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) { [re[i], re[j]] = [re[j], re[i]]; } }
      for (let len = 2; len <= n; len <<= 1) { const a = -2 * Math.PI / len; const wr = Math.cos(a), wi = Math.sin(a);
        for (let i = 0; i < n; i += len) { let cr = 1, ci = 0; for (let k = 0; k < len / 2; k++) { const ur = re[i + k], ui = im[i + k];
          const vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci, vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
          re[i + k] = ur + vr; im[i + k] = ui + vi; re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi; const t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t; } } }
      const out = new Float64Array(n / 2); for (let i = 0; i < n / 2; i++) out[i] = re[i] * re[i] + im[i] * im[i]; return out;
    }
    const out = {};
    for (const biome of ['meadow', 'cherry', 'forest', 'autumn', 'desert', 'snow', 'tropical', 'mushroom']) {
      const ctx = new OfflineAudioContext(2, SR * SECS, SR);
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.knee.value = 12; comp.ratio.value = 4; comp.attack.value = 0.01; comp.release.value = 0.4; comp.connect(ctx.destination);
      const m = new MusicEngine(ctx, comp, biome);
      m.start(biome, 0.7);
      m.renderAhead(SECS);
      const buf = await ctx.startRendering();
      m.stop(0.01);
      const L = buf.getChannelData(0), R = buf.getChannelData(1);
      let peak = 0, sum = 0; for (let i = 0; i < L.length; i++) { const v = (L[i] + R[i]) / 2; peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i])); sum += v * v; }
      const rmsDb = 10 * Math.log10(sum / L.length + 1e-12);
      // спектр по окнам 8192
      const N = 8192; const bands = { sub: 0, low: 0, mid: 0, high: 0, air: 0 }; let total = 0; let windows = 0;
      const winRms = [];
      for (let s = SR * 3; s + N < L.length; s += N) {
        const x = new Float64Array(N); let e = 0;
        for (let i = 0; i < N; i++) { const v = (L[s + i] + R[s + i]) / 2; x[i] = v * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / N)); e += v * v; }
        winRms.push(10 * Math.log10(e / N + 1e-12));
        const mag = fftMag(x);
        for (let k = 1; k < mag.length; k++) { const f = k * SR / N; const v = mag[k]; total += v;
          if (f < 100) bands.sub += v; else if (f < 250) bands.low += v; else if (f < 2000) bands.mid += v; else if (f < 6000) bands.high += v; else bands.air += v; }
        windows++;
      }
      for (const k in bands) bands[k] = +(100 * bands[k] / total).toFixed(1);
      const quiet = winRms.filter((d) => d < -60).length / winRms.length;
      // «гул»: доля окон, где одна и та же самая громкая частота держится 4+ окна подряд (~0.75 с)
      out[biome] = { peak: +peak.toFixed(3), rmsDb: +rmsDb.toFixed(1), bands, silentShare: +(quiet * 100).toFixed(0) };
    }
    return out;
  });
  console.log(JSON.stringify(res, null, 1));
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
