const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  for (const rm of ['no-preference','reduce']) {
    const ctx = await b.newContext({ viewport:{width:1280,height:800}, reducedMotion: rm });
    const p = await ctx.newPage();
    await p.goto('http://127.0.0.1:5173/login');
    await p.evaluate(() => {
      const uid='u_demo';
      localStorage.setItem('pomodoro.users.v1', JSON.stringify({version:1,users:[{id:uid,name:'Катя',email:'demo@example.com',salt:'00',hash:'00',createdAt:new Date().toISOString()}]}));
      localStorage.setItem('pomodoro.auth.v1', JSON.stringify({version:1,userId:uid,signedInAt:new Date().toISOString()}));
      localStorage.setItem('pomodoro.legacy-owner.v1','{}');
      localStorage.setItem('pomodoro.biome.v1@'+uid, JSON.stringify({version:1,biome:'cherry'}));
      localStorage.setItem('pomodoro.world.v1@'+uid, JSON.stringify({version:1,timeOfDay:'day',weather:'rain',effects:true,motion:'full',ambienceOn:true,ambienceVolume:0.5,chime:true}));
      localStorage.setItem('pomodoro.sessions.v1@'+uid, JSON.stringify({version:1,stats:{completed:3,totalFocusMs:0},items:[]}));
    });
    await p.goto('http://127.0.0.1:5173/'); await p.waitForTimeout(2500);
    const r = await p.evaluate(() => {
      const anims = document.getAnimations().filter(a => a.playState === 'running');
      const vis = (sel) => [...document.querySelectorAll(sel)].filter(e => getComputedStyle(e).display !== 'none' && getComputedStyle(e).visibility !== 'hidden').length;
      return { running: anims.length, infinite: anims.filter(a => a.effect?.getTiming().iterations === Infinity).length, particlesVisible: vis('.pt, [class*="pt-"]') };
    });
    console.log(rm, JSON.stringify(r));
    await ctx.close();
  }
  await b.close();
})();
